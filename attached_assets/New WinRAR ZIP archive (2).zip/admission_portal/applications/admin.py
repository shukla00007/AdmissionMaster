from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html
from .models import Application

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'fathers_name', 'mothers_name', 'course_section', 'email', 'phone', 'status', 'submitted_at', 'user', 'print_link')
    list_filter = ('status', 'submitted_at')
    search_fields = ('full_name', 'fathers_name', 'mothers_name', 'course_section', 'email', 'phone', 'address', 'academic_history')
    readonly_fields = ('submitted_at',)
    ordering = ('-submitted_at',)

    def print_link(self, obj):
        url = reverse('print_application', args=[obj.id])
        return format_html('<a href="{}" target="_blank">Print</a>', url)
    print_link.short_description = 'Print'

admin.site.site_header = "SUBHAM'S COLLEGE ADMIN"
admin.site.site_title = "SUBHAM'S ADMISSION PORTAL"
admin.site.index_title = "Welcome to Subham's Admission Portal"
