from django.db import models
from django.contrib.auth.models import User

class Application(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=200)
    fathers_name = models.CharField(max_length=200, null=True, blank=True)
    mothers_name = models.CharField(max_length=200, null=True, blank=True)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    COURSE_CHOICES = [
        ('bsc_cs', 'BSc (Hons) Computer Science'),
        ('bsc_chem', 'BSc (Hons) Chemistry'),
        ('bsc_bio', 'BSc (Hons) Biomedical Science'),
    ]
    course_section = models.CharField(max_length=20, choices=COURSE_CHOICES, null=True, blank=True)
    address = models.TextField()
    academic_history = models.TextField()
    dob = models.DateField(null=True, blank=True)
    photo = models.ImageField(upload_to='photos/', null=True, blank=True)
    signature = models.ImageField(upload_to='signatures/', null=True, blank=True)
    document = models.FileField(upload_to='documents/')
    submitted_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=[
        ('Pending', 'Pending'),
        ('Accepted', 'Accepted'),
        ('Rejected', 'Rejected'),
    ], default='Pending')

    def __str__(self):
        return self.full_name
