from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('apply/', views.apply, name='apply'),
    path('apply/<int:application_id>/', views.apply, name='edit_application'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', views.custom_logout, name='logout'),
    path('print_application/<int:application_id>/', views.print_application, name='print_application'),
    path('final_submit/<int:application_id>/', views.final_submit_application, name='final_submit_application'),
]
