from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from .forms import UserRegistrationForm, ApplicationForm
from .models import Application

def custom_logout(request):
    if request.method == 'POST' or request.method == 'GET':
        logout(request)
        return redirect('home')

def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('dashboard')
    else:
        form = UserRegistrationForm()
    return render(request, 'register.html', {'form': form})


from django.shortcuts import get_object_or_404

@login_required
def apply(request, application_id=None):
    if application_id:
        application = get_object_or_404(Application, id=application_id, user=request.user)
    else:
        application = None

    if request.method == 'POST':
        form = ApplicationForm(request.POST, request.FILES, instance=application)
        if form.is_valid():
            app = form.save(commit=False)
            app.user = request.user
            # Save with status 'Pending' for preview
            app.status = 'Pending'
            app.save()
            # Instead of rendering separate preview page, render apply.html with preview popup
            context = {'form': form, 'show_preview': True, 'application': app}
            return render(request, 'apply.html', context)
        else:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Application form errors: {form.errors}")
            # Pass existing file URLs to template for preview
            context = {'form': form}
            if application:
                if application.photo:
                    context['photo_url'] = application.photo.url
                if application.signature:
                    context['signature_url'] = application.signature.url
                if application.document:
                    context['document_url'] = application.document.url
            return render(request, 'apply.html', context)
    else:
        form = ApplicationForm(instance=application)
    return render(request, 'apply.html', {'form': form})

@login_required
def final_submit_application(request, application_id):
    application = get_object_or_404(Application, id=application_id, user=request.user)
    if request.method == 'POST':
        application.status = 'Accepted'
        application.save()
        # Redirect to print_application page after final submit as per user request
        return redirect('print_application', application_id=application_id)
    else:
        return redirect('print_application', application_id=application_id)

from django.contrib.auth.decorators import login_required, user_passes_test

@login_required
def print_application(request, application_id):
    try:
        if request.user.is_superuser:
            application = Application.objects.get(id=application_id)
        else:
            application = Application.objects.get(id=application_id, user=request.user)
    except Application.DoesNotExist:
        return redirect('dashboard')
    return render(request, 'print_application.html', {'application': application})

from django.contrib.auth import logout
from django.shortcuts import redirect

@login_required
def dashboard(request):
    applications = Application.objects.filter(user=request.user)
    if applications is None:
        applications = []
    return render(request, 'dashboard.html', {'applications': applications})
